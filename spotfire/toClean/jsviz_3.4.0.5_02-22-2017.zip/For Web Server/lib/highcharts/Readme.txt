For legal reasons we cannot include the highcharts libraries in the JSViz distribution

Before opening the highcharts samples, download and unzip highcharts-3.0.6.zip into this folder.

You should see the following sub-items:

	examples (folder)
	exporting-server (folder)
	gfx (folder)
	graphics (folder)
	js (folder)
	index.htm (file)