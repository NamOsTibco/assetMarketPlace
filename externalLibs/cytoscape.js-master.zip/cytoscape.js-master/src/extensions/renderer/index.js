'use strict';

module.exports = [
  { name: 'null', impl: require( './null' ) },
  { name: 'base', impl: require( './base' ) },
  { name: 'canvas', impl: require( './canvas' ) }
];
