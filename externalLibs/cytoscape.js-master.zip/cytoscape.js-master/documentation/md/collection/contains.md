## Examples

```js
cy.$('#j, #e').contains( cy.$('#j') ); // true
```
