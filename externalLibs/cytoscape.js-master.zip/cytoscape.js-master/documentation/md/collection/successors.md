## Examples

Get successors of `j`:
```js
cy.$('#j').successors();
```