## Details

<span class="important-indicator"></span> Note that as an alternative, you may read `eles.length` instead of `eles.size()`.  The two are interchangeable.