## Examples

```js
cy.$('#j').pon('tap').then(function( event ){
  console.log('tap promise fulfilled');
});
```
