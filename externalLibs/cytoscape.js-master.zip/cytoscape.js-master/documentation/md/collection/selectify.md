## Examples

```js
cy.$('#j').unselectify();
```