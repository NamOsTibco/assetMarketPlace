## Details

This function returns a plain object with the fields `x1`, `x2`, `y1`, `y2`, `w`, and `h` defined.