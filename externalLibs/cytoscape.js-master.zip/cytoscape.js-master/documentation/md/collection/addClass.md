## Examples

```js
cy.$('#j, #e').addClass('foo');
```