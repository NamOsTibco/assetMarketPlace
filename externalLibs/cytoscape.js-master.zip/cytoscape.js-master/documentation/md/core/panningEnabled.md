## Examples

Enable:
```js
cy.panningEnabled( true );
```

Disable:
```js
cy.panningEnabled( false );
```