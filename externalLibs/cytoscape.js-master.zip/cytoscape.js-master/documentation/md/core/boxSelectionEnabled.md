## Examples

Enable:
```js
cy.boxSelectionEnabled( true );
```

Disable:
```js
cy.boxSelectionEnabled( false );
```