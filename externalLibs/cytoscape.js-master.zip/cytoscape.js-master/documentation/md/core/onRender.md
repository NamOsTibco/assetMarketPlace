## Examples

```js
cy.onRender(function(){
  console.log('frame rendered');
});
```