$(function(){
  $('head').prepend('<script src="http://' + window.location.hostname + ':35729/livereload.js"></script>');
});
